package com.example.root.buapp.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.SimpleAdapter;


import com.example.root.buapp.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class CoursesActivity extends AppCompatActivity {

    // Array of strings for ListView Title
    String[] listviewTitle = new String[]{
            "IUK-DIT225: Business Ethics", "IUK-DIT225: Programming C", "IUK-DIT225: Basic Electronics", "IUK-DIT225: Data Structures",
            "IUK-DIT225: Multimedia Arch", "IUK-DIT225: Web Scripting", "IUK-DIT225: Physics", "IUK-DIT225: Communication Skills",
            "IUK-DIT225: Fundamentals of IT", "IUK-DIT225: Computer organization", "IUK-DIT225: Office Automation", "IUK-DIT225: Mathematics for IT",
            "IUK-DIT225: Computer Networks", "IUK-DIT225: Operating System", "IUK-DIT225: Digital Electronics", "IUK-DIT225: Programming in Java",
            "IUK-DIT225: Application development", "IUK-DIT225: Cloud Computing", "IUK-DIT225: Technical Communication", "IUK-DIT225: Open Source Software",
            "IUK-DIT225: Software engineering", "IUK-DIT225: Mobile application", "IUK-DIT225: Database Management", "IUK-DIT225: Database lab",
    };


    int[] listviewImage = new int[]{
            R.drawable.course, R.drawable.course, R.drawable.course, R.drawable.course,
            R.drawable.course, R.drawable.course, R.drawable.course, R.drawable.course,
            R.drawable.course, R.drawable.course, R.drawable.course, R.drawable.course,
            R.drawable.course, R.drawable.course, R.drawable.course, R.drawable.course,
            R.drawable.course, R.drawable.course, R.drawable.course, R.drawable.course,
            R.drawable.course, R.drawable.course, R.drawable.course, R.drawable.course,
    };

    String[] listviewShortDescription = new String[]{
            "ROOM: 204 TIME: 8am-10am", "ROOM: 204 TIME: 8am-10am", "ROOM: 204 TIME: 8am-10am", "ROOM: 204 TIME: 8am-10am",
            "ROOM: 204 TIME: 8am-10am", "ROOM: 204 TIME: 8am-10am", "ROOM: 204 TIME: 8am-10am", "ROOM: 204 TIME: 8am-10am",
            "ROOM: 204 TIME: 8am-10am", "ROOM: 204 TIME: 8am-10am", "ROOM: 204 TIME: 8am-10am", "ROOM: 204 TIME: 8am-10am",
            "ROOM: 204 TIME: 8am-10am", "ROOM: 204 TIME: 8am-10am", "ROOM: 204 TIME: 8am-10am", "ROOM: 204 TIME: 8am-10am",
            "ROOM: 204 TIME: 8am-10am", "ROOM: 204 TIME: 8am-10am", "ROOM: 204 TIME: 8am-10am", "ROOM: 204 TIME: 8am-10am",
            "ROOM: 204 TIME: 8am-10am", "ROOM: 204 TIME: 8am-10am", "ROOM: 204 TIME: 8am-10am", "ROOM: 204 TIME: 8am-10am",
    };
    String[] listviewShortDescription2 = new String[]{
            "LECTURER: Mr.John Doe", "LECTURER: Mr.John Doe", "LECTURER: Mr.John Doe", "LECTURER: Mr.John Doe",
            "LECTURER: Mr.John Doe", "LECTURER: Mr.John Doe", "LECTURER: Mr.John Doe", "LECTURER: Mr.John Doe",
            "LECTURER: Mr.John Doe", "LECTURER: Mr.John Doe", "LECTURER: Mr.John Doe", "LECTURER: Mr.John Doe",
            "LECTURER: Mr.John Doe", "LECTURER: Mr.John Doe", "LECTURER: Mr.John Doe", "LECTURER: Mr.John Doe",
            "LECTURER: Mr.John Doe", "LECTURER: Mr.John Doe", "LECTURER: Mr.John Doe", "LECTURER: Mr.John Doe",
            "LECTURER: Mr.John Doe", "LECTURER: Mr.John Doe", "LECTURER: Mr.John Doe", "LECTURER: Mr.John Doe",
    };



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listview_with_image_and_text);


        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        List<HashMap<String, String>> aList = new ArrayList<HashMap<String, String>>();

        for (int i = 0; i < 24; i++) {
            HashMap<String, String> hm = new HashMap<String, String>();
            hm.put("listview_title", listviewTitle[i]);
            hm.put("listview_discription", listviewShortDescription[i]);
            hm.put("listview_discription2", listviewShortDescription2[i]);
            hm.put("listview_image", Integer.toString(listviewImage[i]));
            aList.add(hm);
        }

        String[] from = {"listview_image", "listview_title", "listview_discription","listview_discription2"};
        int[] to = {R.id.listview_image, R.id.listview_item_title, R.id.listview_item_short_description, R.id.listview_item_short_description2};

        SimpleAdapter simpleAdapter = new SimpleAdapter(getBaseContext(), aList, R.layout.activity_courses, from, to);
        ListView androidListView = (ListView) findViewById(R.id.list_view);
        androidListView.setAdapter(simpleAdapter);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == android.R.id.home) {
            // finish the activity
            onBackPressed();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
